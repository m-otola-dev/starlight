
SET FOREIGN_KEY_CHECKS = 0;
drop table if exists clients;
drop table if exists planets;
drop table if exists sales;
drop table if exists funFacts;
drop table if exists information;
SET FOREIGN_KEY_CHECKS = 1;